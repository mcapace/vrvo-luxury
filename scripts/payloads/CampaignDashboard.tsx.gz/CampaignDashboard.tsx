'use client'

import type { CampaignReport } from '@/lib/data/bigSmokeMiami'
import { downloadCampaignReportCsv } from '@/lib/reportingExport'
import { PrebookedCampaignDashboard } from './PrebookedCampaignDashboard'
import Link from 'next/link'
import { useCallback, useMemo, useState, type ReactNode } from 'react'
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  Line,
  LineChart,
  Area,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceArea,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
} from 'recharts'

function isPlanningViewCampaign(id: string): boolean {
  return id.startsWith('plan_') || id.startsWith('scenario_')
}

/** Palette inspired by DSP overview UIs (clean whites + navy + semantic chart hues). */
const TTD = {
  navy: '#1E3A5F',
  navyMuted: '#2C4F7C',
  teal: '#0d9488',
  orange: '#ea580c',
  orangeLight: '#fb923c',
  purple: '#7c3aed',
  slate: '#64748b',
  plan: '#94a3b8',
  grid: '#e2e8f0',
  /**
   * Quadrant matrix fills — tuned to read like common Trade Desk–style goal vs pacing views:
   * upper-right = healthy (cool mint green), upper-left = goal pressure (harvest gold),
   * lower-left = critical (rose/coral), lower-right = pacing pressure with goal intact (blue).
   */
  quadrant: {
    goalOkPaceOk: 'rgba(16, 185, 129, 0.26)',
    goalRiskPaceOk: 'rgba(251, 191, 36, 0.34)',
    goalRiskPaceRisk: 'rgba(251, 113, 133, 0.26)',
    goalOkPaceRisk: 'rgba(59, 130, 246, 0.22)',
  },
  refGoal: '#0f766e',
  refPace: '#1E3A5F',
  /** Budget / cap reference (matches forecast accent family in DSP UIs) */
  refCap: '#b91c1c',
  forecast: '#dc2626',
}

/** Unified Recharts presentation — matches quadrant “Trade Desk–style” density & palette */
const CHART = {
  marginLg: { top: 14, right: 18, left: 10, bottom: 10 },
  marginMd: { top: 12, right: 16, left: 8, bottom: 10 },
  tick: { fontSize: 10, fill: TTD.slate },
  tickSm: { fontSize: 9, fill: TTD.slate },
  gridH: { stroke: TTD.grid, strokeDasharray: '4 4' as const },
  gridV: { stroke: TTD.grid, strokeDasharray: '4 4' as const },
  tooltip: {
    contentStyle: {
      fontSize: 11,
      border: '1px solid #e2e8f0',
      borderRadius: 8,
      boxShadow: '0 4px 14px rgba(15, 23, 42, 0.09)',
    },
  },
  legend: { wrapperStyle: { fontSize: 11, paddingTop: 10 } },
}

function formatNumber(n: number) {
  return new Intl.NumberFormat('en-US').format(n)
}

function formatPercent(n: number, fractionDigits = 1) {
  return `${n.toFixed(fractionDigits)}%`
}

function formatDurationSec(totalSec: number) {
  const m = Math.floor(totalSec / 60)
  const s = Math.round(totalSec % 60)
  return `${m}m ${String(s).padStart(2, '0')}s`
}

function formatShortDate(iso: string) {
  const [, m, day] = iso.split('-')
  return `${m}/${day}`
}

/** Full calendar month → "May 2026"; partial / multi-week slice → "May 5–11, 2026". */
function formatDeliveryPeriodLabel(isoStart: string, isoEnd: string) {
  const [ys, ms, ds] = isoStart.split('-').map(Number)
  const [ye, me, de] = isoEnd.split('-').map(Number)
  const start = new Date(Date.UTC(ys, ms - 1, ds))
  const end = new Date(Date.UTC(ye, me - 1, de))
  const lastDayOfStartMonth = new Date(Date.UTC(ys, ms, 0)).getUTCDate()
  const isFullCalendarMonth =
    ys === ye && ms === me && ds === 1 && de === lastDayOfStartMonth

  if (isFullCalendarMonth) {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC',
    }).format(start)
  }

  const sameMonthYear = ys === ye && ms === me
  if (sameMonthYear) {
    const month = new Intl.DateTimeFormat('en-US', {
      month: 'short',
      timeZone: 'UTC',
    }).format(start)
    return `${month} ${ds}–${de}, ${ys}`
  }

  const fmt = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  })
  return `${fmt.format(start)} – ${fmt.format(end)}`
}

function formatPeriodDateRange(start: string, end: string) {
  const startDate = new Date(`${start}T12:00:00.000Z`)
  const endDate = new Date(`${end}T12:00:00.000Z`)
  const sameYear = start.slice(0, 4) === end.slice(0, 4)
  const fmt = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: sameYear ? undefined : 'numeric',
    timeZone: 'UTC',
  })
  const endFmt = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  })
  return `${fmt.format(startDate)} – ${endFmt.format(endDate)}`
}

function traffickingActionLabel(action: 'launch' | 'swap' | 'refresh' | 'close') {
  switch (action) {
    case 'launch':
      return 'Launch'
    case 'swap':
      return 'Swap'
    case 'refresh':
      return 'Refresh'
    case 'close':
      return 'Close'
  }
}

function formatReportTs(iso: string) {
  const d = new Date(iso)
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
    timeZone: 'America/New_York',
  }).format(d)
}

function scrollToReportingSection(id: string) {
  const el = document.getElementById(id)
  if (!el) return
  el.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

const RIBBON_ACTION =
  'rounded-sm px-2 py-1 text-left text-white/95 transition-colors hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/50'
const RIBBON_ACTION_PRIMARY = `${RIBBON_ACTION} bg-white/15 hover:bg-white/20`

function bubbleFill(goal: number, pace: number): string {
  const gx = goal >= 90
  const py = pace >= 90
  // Match quadrant semantic hues (TTD-style traffic-light matrix)
  if (gx && py) return '#059669'
  if (!gx && py) return '#d97706'
  if (!gx && !py) return '#e11d48'
  return '#2563eb'
}

function csvCell(value: string | number): string {
  const text = String(value)
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

function gamLongDate(iso: string): string {
  const [year, month, day] = iso.split('-').map(Number)
  return new Date(Date.UTC(year, month - 1, day)).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  })
}

function gamCtr(clicks: number, impressions: number): string {
  if (impressions <= 0 || clicks <= 0) return '0.0'
  return (clicks / impressions).toFixed(4).replace(/0+$/, '').replace(/\.$/, '')
}

function gamCreativeSlug(lineId: string, format: string): string {
  const size = format.match(/\d+x\d+/)?.[0]
  if (lineId === 'mid-april-popups') {
    return format.includes('Interstitial') ? 'high_impact_interstitial_popup' : 'mobile_overlay'
  }
  if (lineId === 'belicoso-banner-a-makegood') return `wsc_tlh_belicoso_banner_a_${size ?? 'unit'}_html5`
  if (lineId === 'may-8-puro-sponsored') {
    return format.includes('Card') ? 'puro_dominicano_native_card' : 'puro_dominicano_editorial'
  }
  if (lineId === 'june-26-avo-sponsored') {
    return format.includes('Card') ? 'avo_expresivo_native_card' : 'avo_expresivo_editorial'
  }
  if (lineId === 'june-17-puro-ros') return `puro_dominicano_ros_${size ?? 'unit'}_html5`
  if (lineId === 'june-25-avo-ros') return `avo_expresivo_ros_${size ?? 'unit'}_html5`
  if (lineId === 'mid-may-ros') return `mid_may_ros_${size ?? 'unit'}_html5`
  return `${lineId.replace(/-/g, '_')}_${size ?? 'unit'}`
}

function allocateExact(total: number, weights: number[]): number[] {
  const safe = weights.map((weight) => (weight > 0 ? weight : 0))
  const weightSum = safe.reduce((sum, weight) => sum + weight, 0)
  if (weightSum <= 0) return safe.map(() => 0)
  const exact = safe.map((weight) => (total * weight) / weightSum)
  const counts = exact.map((value) => Math.floor(value))
  let remainder = total - counts.reduce((sum, value) => sum + value, 0)
  const order = exact
    .map((value, index) => ({ index, fraction: value - counts[index] }))
    .sort((a, b) => b.fraction - a.fraction || a.index - b.index)
  for (let i = 0; i < remainder; i++) counts[order[i].index] += 1
  return counts
}

function splitByShare(dayTotals: number[], shares: number[]): number[][] {
  const width = shares.length
  const grand = dayTotals.reduce((sum, value) => sum + value, 0)
  const columnTarget = allocateExact(grand, shares)
  const cells = dayTotals.map((total) => allocateExact(total, shares))
  const column = Array.from({ length: width }, () => 0)
  cells.forEach((row) => row.forEach((value, index) => { column[index] += value }))
  let guard = 0
  while (guard++ < grand + width) {
    let donor = -1
    let receiver = -1
    for (let index = 0; index < width; index++) {
      if (column[index] > columnTarget[index] && (donor < 0 || column[index] - columnTarget[index] > column[donor] - columnTarget[donor])) {
        donor = index
      }
      if (column[index] < columnTarget[index] && (receiver < 0 || columnTarget[index] - column[index] > columnTarget[receiver] - column[receiver])) {
        receiver = index
      }
    }
    if (donor < 0 || receiver < 0) break
    const rowIndex = cells.findIndex((row) => row[donor] > 0)
    if (rowIndex < 0) break
    cells[rowIndex][donor] -= 1
    cells[rowIndex][receiver] += 1
    column[donor] -= 1
    column[receiver] += 1
  }
  return cells
}

function downloadGamHistoricalCsv(campaign: CampaignReport, generatedAt: string) {
  const lines = campaign.creativeLines ?? []
  const order = campaign.id.startsWith('davidoff_2026') ? 'DAVIDOFF-2026-CA-SUITE' : campaign.tradeDesk.meta.ioNumber
  const detail = lines.flatMap((line) => {
    const formats = line.tradeDesk.formatDelivery
    const shares = formats.map((row) => row.sharePct)
    const impressionParts = splitByShare(
      line.tradeDesk.daily.map((day) => day.actualImp),
      shares,
    )
    const clickParts = splitByShare(
      line.tradeDesk.daily.map((day) => day.clicks),
      shares,
    )
    const cpm = line.delivery.cpmUsd
    return line.tradeDesk.daily.flatMap((day, dayIndex) =>
      formats.map((format, formatIndex) => ({
        date: day.date,
        creative: gamCreativeSlug(line.id, format.format),
        impressions: impressionParts[dayIndex]?.[formatIndex] ?? 0,
        clicks: clickParts[dayIndex]?.[formatIndex] ?? 0,
        cpm,
      })),
    )
  })
  detail.sort((a, b) => a.creative.localeCompare(b.creative) || a.date.localeCompare(b.date))
  const dates = detail.map((row) => row.date).sort()
  const first = dates[0] ?? campaign.flight.launched
  const last = dates[dates.length - 1] ?? campaign.flight.launched
  const generated = new Date(generatedAt)
  const generatedLabel = Number.isNaN(generated.getTime())
    ? generatedAt
    : `${generated.toLocaleString('en-US', {
        timeZone: 'America/New_York',
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      })} EDT`
  const filter =
    lines.length === 1 ? `Line item = ${lines[0].label}` : `Order = ${order}`
  const header = [
    ['Report name', 'Ad Manager Report'].join(','),
    ['Report type', 'Historical'].join(','),
    ['Report result ID', ''].join(','),
    ['Report currency', 'USD'].join(','),
    ['Publisher network', 'M Shanken - DFP'].join(','),
    ['User', 'mcapace@mshanken.com'].join(','),
    ['Date/Time generated', generatedLabel].map(csvCell).join(','),
    ['Date range', `${gamLongDate(first)} - ${gamLongDate(last)}`].map(csvCell).join(','),
    ['Time zone', 'America/New_York'].join(','),
    ['Filters', filter].map(csvCell).join(','),
    '',
    ['Creative', 'Date', 'Ad server impressions', 'Ad server clicks', 'Ad server CTR', 'Ad server CPM and CPC revenue', 'Ad server average eCPM w/o CPD'].join(','),
  ]
  const body = detail.map((row) => {
    const revenue = (row.impressions * row.cpm) / 1000
    return [
      row.creative,
      row.date,
      row.impressions,
      row.clicks,
      gamCtr(row.clicks, row.impressions),
      revenue.toFixed(2),
      row.impressions > 0 ? row.cpm.toFixed(2) : '0.00',
    ].join(',')
  })
  const csv = [...header, ...body, ''].join('\n')
  const slug = lines.length === 1 ? `_${lines[0].id}` : ''
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = `Ad_Manager_Report_${order}${slug}.csv`
  anchor.click()
  URL.revokeObjectURL(url)
}

function campaignViewForLine(
  campaign: CampaignReport,
  line: NonNullable<CampaignReport['creativeLines']>[number],
): CampaignReport {
  const periodRows = (campaign.billingPeriods ?? []).filter((row) => row.creativeLabel === line.label)
  const launched = line.tradeDesk.daily[0]?.date ?? periodRows[0]?.start ?? campaign.flight.launched
  return {
    ...campaign,
    id: `${campaign.id}__${line.id}`,
    name: line.label,
    clientFacingName: line.label,
    delivery: line.delivery,
    performance: line.performance,
    creative: line.creative,
    tracking: line.tracking,
    tradeDesk: line.tradeDesk,
    monthlyDelivery: line.monthlyDelivery ?? [],
    monthlyDeliveryNote: line.monthlyDeliveryNote,
    overviewObjectiveSub: line.overviewObjectiveSub,
    billingPeriods: periodRows.length ? periodRows : campaign.billingPeriods,
    creativeLines: [line],
    flight: {
      ...campaign.flight,
      launched,
      summary: line.overviewObjectiveSub ?? line.performance.measurementNote,
    },
  }
}

export function CampaignDashboard({
  campaign,
  /** Server request time — true “last refresh” for this page view. */
  generatedAt,
  /** When set, ribbon shows “Expand report” (e.g. order-entry page with a narrow preview column). */
  onExpandReport,
}: {
  campaign: CampaignReport
  generatedAt: string
  onExpandReport?: () => void
}) {
  const creativeLines = campaign.creativeLines ?? []
  const hasCreativeLines = creativeLines.length > 0
  const [activeLineId, setActiveLineId] = useState<string>('all')

  const activeLine = useMemo(
    () => (activeLineId === 'all' ? null : creativeLines.find((l) => l.id === activeLineId) ?? null),
    [activeLineId, creativeLines],
  )

  const delivery = activeLine?.delivery ?? campaign.delivery
  const tradeDesk = activeLine?.tradeDesk ?? campaign.tradeDesk
  const performance = activeLine?.performance ?? campaign.performance
  const monthlyDelivery = activeLine?.monthlyDelivery ?? campaign.monthlyDelivery
  const monthlyDeliveryNote = activeLine?.monthlyDeliveryNote ?? campaign.monthlyDeliveryNote
  const creative = activeLine?.creative ?? campaign.creative
  const tracking = activeLine?.tracking ?? campaign.tracking
  const overviewObjectiveSub = activeLine?.overviewObjectiveSub ?? campaign.overviewObjectiveSub

  const deliveredImp =
    typeof delivery.deliveredImpressions === 'number' && Number.isFinite(delivery.deliveredImpressions)
      ? Math.round(delivery.deliveredImpressions)
      : Math.round((delivery.impressionsPurchased * delivery.pctDelivered) / 100)
  const mediaCost = (deliveredImp / 1000) * delivery.cpmUsd
  const bookedSpend = (delivery.impressionsPurchased / 1000) * delivery.cpmUsd

  const totalClicks = useMemo(
    () => tradeDesk.daily.reduce((a, r) => a + r.clicks, 0),
    [tradeDesk.daily],
  )
  const blendedCtr =
    deliveredImp > 0 ? (totalClicks / deliveredImp) * 100 : performance.ctrPct
  const cpc = totalClicks > 0 ? mediaCost / totalClicks : 0

  const last7 = useMemo(() => tradeDesk.daily.slice(-7), [tradeDesk.daily])
  const prev7 = useMemo(() => tradeDesk.daily.slice(-14, -7), [tradeDesk.daily])

  const avgDailyLast7 =
    last7.length > 0 ? last7.reduce((a, r) => a + r.actualImp, 0) / last7.length : 0
  const avgDailyPrior7 =
    prev7.length > 0 ? prev7.reduce((a, r) => a + r.actualImp, 0) / prev7.length : 0
  const pacingWoW =
    avgDailyPrior7 > 0 ? ((avgDailyLast7 - avgDailyPrior7) / avgDailyPrior7) * 100 : 0

  const cumulativeChartData = useMemo(
    () =>
      tradeDesk.daily.map((d) => ({
        ...d,
        shortDate: formatShortDate(d.date),
        pacePct: d.paceIndex * 100 - 100,
      })),
    [tradeDesk.daily],
  )

  const spendAreaData = useMemo(
    () =>
      cumulativeChartData.map((d) => ({
        ...d,
        spendK: Math.round(d.cumulativeActual / 1000),
        forecastK: Math.round(d.cumulativePlanned / 1000),
      })),
    [cumulativeChartData],
  )

  const devicePieData = tradeDesk.deviceSplit.map((d) => ({
    name: d.device,
    value: d.sharePct,
  }))

  const dataActivationPie = useMemo(() => {
    if (campaign.audienceActivationMix?.length) return campaign.audienceActivationMix
    return [
      { name: 'Modeled / scale', value: 52 },
      { name: 'Purchase / POS', value: 31 },
      { name: 'Contextual / lifestyle', value: 17 },
    ]
  }, [campaign.audienceActivationMix, campaign.id])

  const channelBars = useMemo(() => {
    const rows = [...tradeDesk.geoDelivery]
      .sort((a, b) => b.impressions - a.impressions)
      .slice(0, 7)
      .map((g) => ({
        label: g.region.length > 18 ? `${g.region.slice(0, 16)}…` : g.region,
        imps: g.impressions,
      }))
    const max = Math.max(...rows.map((r) => r.imps), 1)
    return rows.map((r) => ({ ...r, pct: Math.round((r.imps / max) * 100) }))
  }, [tradeDesk.geoDelivery])

  const monthlyRows = useMemo(() => {
    if (!monthlyDelivery?.length) return []
    return monthlyDelivery.map((seg) => ({
      ...seg,
      label: formatDeliveryPeriodLabel(seg.start, seg.end),
      ctrPct: seg.impressions > 0 ? (seg.clicks / seg.impressions) * 100 : 0,
    }))
  }, [monthlyDelivery])

  const billingPeriodRows = useMemo(() => {
    if (!campaign.billingPeriods?.length) return []
    return campaign.billingPeriods.map((row) => ({
      ...row,
      dateLabel: formatPeriodDateRange(row.start, row.end),
      ctrPct: row.impressions > 0 ? (row.clicks / row.impressions) * 100 : 0,
    }))
  }, [campaign.billingPeriods])

  const showBillingTable = billingPeriodRows.length > 0
  const showMonthlyTable = monthlyRows.length > 0 && !showBillingTable

  const funnelTiers = useMemo(() => {
    const booked = delivery.impressionsPurchased
    const delivered = deliveredImp
    const deliveredBarPct =
      booked > 0 ? Math.max(12, Math.min(100, Math.round((delivered / booked) * 100))) : 0
    const clickBarPct =
      booked > 0
        ? Math.max(10, Math.min(100, Math.round((totalClicks / booked) * 6_000)))
        : 0
    return [
      { label: 'Booked reach', value: booked, widthPct: 100 },
      { label: 'Delivered imps', value: delivered, widthPct: deliveredBarPct },
      { label: 'Clicks', value: totalClicks, widthPct: clickBarPct },
    ]
  }, [delivery.impressionsPurchased, deliveredImp, totalClicks])

  const bubbleData = useMemo(() => {
    const maxImp = Math.max(...tradeDesk.formatDelivery.map((f) => f.impressions), 1)
    return tradeDesk.formatDelivery.map((f, i) => {
      const goalOnTrack = Math.min(
        99,
        62 + (f.sharePct * 0.75 + (f.impressions / maxImp) * 28 + ((i * 13) % 9)),
      )
      const pacing = Math.min(99, 58 + (f.impressions / maxImp) * 38 + ((i * 7) % 12))
      return {
        name: f.format.replace(/×/g, '×'),
        goalOnTrack: Math.round(goalOnTrack * 10) / 10,
        pacing: Math.round(pacing * 10) / 10,
        spend: f.impressions,
        fill: bubbleFill(goalOnTrack, pacing),
      }
    })
  }, [tradeDesk.formatDelivery])

  const lastDay = tradeDesk.daily[tradeDesk.daily.length - 1]
  const varianceAhead = lastDay ? lastDay.cumulativeActual > lastDay.cumulativePlanned : false

  const exportReportFor = useCallback((lineId: string) => {
    const davidoff = campaign.id.startsWith('davidoff_2026')
    if (lineId === 'all') {
      if (davidoff) downloadGamHistoricalCsv(campaign, generatedAt)
      else downloadCampaignReportCsv(campaign, { generatedAt })
      return
    }
    const line = creativeLines.find((item) => item.id === lineId)
    if (!line) return
    const view = campaignViewForLine(campaign, line)
    if (davidoff) downloadGamHistoricalCsv(view, generatedAt)
    else downloadCampaignReportCsv(view, { generatedAt })
  }, [campaign, creativeLines, generatedAt])

  const handleExportReport = useCallback(() => {
    exportReportFor(activeLineId)
  }, [activeLineId, exportReportFor])

  const resolveDelivered = useCallback((d: CampaignReport['delivery']) => {
    if (typeof d.deliveredImpressions === 'number' && Number.isFinite(d.deliveredImpressions)) {
      return Math.round(d.deliveredImpressions)
    }
    return Math.round((d.impressionsPurchased * d.pctDelivered) / 100)
  }, [])

  const creativeLineRows = useMemo(() => {
    if (!creativeLines.length) return []
    return creativeLines.map((line) => {
      const del = resolveDelivered(line.delivery)
      const clicks = line.tradeDesk.daily.reduce((a, r) => a + r.clicks, 0)
      const ctr = del > 0 ? (clicks / del) * 100 : line.performance.ctrPct
      const spend = (del / 1000) * line.delivery.cpmUsd
      return {
        id: line.id,
        label: line.label,
        kind: line.kind,
        booked: line.delivery.impressionsPurchased,
        delivered: del,
        clicks,
        ctr,
        spend,
        cpm: line.delivery.cpmUsd,
        pmpSharePct: line.performance.pmpSharePct,
        vcrPct: line.performance.vcrPct,
        lineItem: line.tradeDesk.meta.lineItem,
      }
    })
  }, [creativeLines, resolveDelivered])

  const selectCreativeLine = useCallback((id: string) => {
    setActiveLineId(id)
    // Let state flush, then scroll to the live KPI / charts for this line.
    requestAnimationFrame(() => {
      scrollToReportingSection('reporting-campaign-overview')
    })
  }, [])

  if (campaign.flight.prebookedPending) {
    return (
      <PrebookedCampaignDashboard
        campaign={campaign}
        generatedAt={generatedAt}
        onExpandReport={onExpandReport}
      />
    )
  }

  return (
    <div
      data-reporting-dashboard="v3-dsp-overview"
      className="min-h-screen bg-white pb-12 font-body shadow-[0_0_0_1px_rgba(15,23,42,0.06)] sm:mx-auto sm:max-w-[1420px] sm:rounded-b-xl"
    >
      {/* Utility ribbon — DSP-style shortcuts */}
      <div className="border-b border-navy/80 bg-navy">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center gap-1 px-3 py-2 text-[11px] font-medium sm:px-5">
          <button
            type="button"
            onClick={handleExportReport}
            className={RIBBON_ACTION_PRIMARY}
            aria-label="Export campaign report as CSV"
          >
            Export report
          </button>
          <span className="text-white/40">|</span>
          <button
            type="button"
            onClick={() => scrollToReportingSection('reporting-schedule-report')}
            className={RIBBON_ACTION}
          >
            Schedule report
          </button>
          <span className="text-white/40">|</span>
          <button
            type="button"
            onClick={() => scrollToReportingSection('reporting-line-items')}
            className={RIBBON_ACTION}
          >
            Line items
          </button>
          <span className="text-white/40">|</span>
          <button
            type="button"
            onClick={() => scrollToReportingSection('reporting-creative')}
            className={RIBBON_ACTION}
          >
            Creative
          </button>
          {showBillingTable || showMonthlyTable ? (
            <>
              <span className="text-white/40">|</span>
              <button
                type="button"
                onClick={() => scrollToReportingSection('reporting-monthly-delivery')}
                className={RIBBON_ACTION}
              >
                {showBillingTable ? 'Billing periods' : 'Monthly delivery'}
              </button>
            </>
          ) : null}
          {campaign.creativeTraffickingLog?.length ? (
            <>
              <span className="text-white/40">|</span>
              <button
                type="button"
                onClick={() => scrollToReportingSection('reporting-trafficking-log')}
                className={RIBBON_ACTION}
              >
                Trafficking log
              </button>
            </>
          ) : null}
          {campaign.landingPage ? (
            <>
              <span className="text-white/40">|</span>
              <button
                type="button"
                onClick={() => scrollToReportingSection('reporting-landing-page')}
                className={RIBBON_ACTION}
              >
                Landing page
              </button>
            </>
          ) : null}
          <span className="ml-auto flex flex-wrap items-center gap-x-3 gap-y-1 tabular-nums text-white/70">
            {onExpandReport ? (
              <>
                <button
                  type="button"
                  onClick={onExpandReport}
                  className={RIBBON_ACTION}
                  aria-label="Expand report to full window"
                >
                  Expand report
                </button>
                <span className="text-white/40">|</span>
              </>
            ) : null}
            <Link
              href="/reporting/scenario"
              className="font-medium text-white/95 underline decoration-white/30 underline-offset-2 transition-colors hover:text-white hover:decoration-white/60"
            >
              New order
            </Link>
            <span className="text-white/40">|</span>
            <span>IO {tradeDesk.meta.ioNumber}</span>
          </span>
        </div>
      </div>

      {/* Welcome row */}
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1400px] px-4 py-5 sm:px-6">
          <p className="text-sm text-slate-600">Welcome back — partner overview</p>
          <div className="mt-1 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-slate-900 sm:text-[26px]">
                {campaign.name}
              </h1>
              <p className="mt-1 max-w-3xl text-sm text-slate-600">{campaign.flight.summary}</p>
            </div>
            <div className="text-right text-xs text-slate-500">
              <div>
                Last refresh{' '}
                <span className="font-medium text-slate-800">
                  {formatReportTs(generatedAt)}
                </span>
              </div>
              <div className="mt-0.5">{tradeDesk.meta.lineItem}</div>
            </div>
          </div>

          {/* KPI strip — includes optional PMP / VCR when present */}
          <div
            className={`mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-slate-200 bg-slate-200 sm:grid-cols-4 ${
              typeof performance.pmpSharePct === 'number' || typeof performance.vcrPct === 'number'
                ? 'lg:grid-cols-5'
                : 'lg:grid-cols-8'
            }`}
          >
            <SnapshotCell label="Booked imps" value={formatNumber(delivery.impressionsPurchased)} />
            <SnapshotCell label="Delivered imps" value={formatNumber(deliveredImp)} accent />
            <SnapshotCell label="Flight completion" value={formatPercent(delivery.pctDelivered, 0)} />
            <SnapshotCell label="Est. spend (del.)" value={`$${formatNumber(Math.round(mediaCost * 100) / 100)}`} />
            <SnapshotCell label="Booked value" value={`$${formatNumber(Math.round(bookedSpend * 100) / 100)}`} />
            <SnapshotCell label="CTR" value={formatPercent(blendedCtr, 3)} />
            <SnapshotCell label="Clicks" value={formatNumber(totalClicks)} />
            <SnapshotCell label="CPC" value={`$${cpc.toFixed(3)}`} />
            {typeof performance.pmpSharePct === 'number' ? (
              <SnapshotCell
                label="PMP / endemic share"
                value={formatPercent(performance.pmpSharePct, 1)}
                accent
              />
            ) : null}
            {typeof performance.vcrPct === 'number' ? (
              <SnapshotCell
                label={activeLine?.kind === 'native' ? 'VCR (n/a)' : 'VCR (video complete)'}
                value={
                  activeLine?.kind === 'native'
                    ? '—'
                    : formatPercent(performance.vcrPct, 1)
                }
              />
            ) : null}
          </div>

          {hasCreativeLines ? (
            <div className="mt-5 rounded-lg border-2 border-navy/30 bg-slate-50 p-4">
              <p className="text-sm font-semibold text-slate-900">
                Choose a line to view
              </p>
              <p className="mt-1 text-xs text-slate-600">
                Native and pre-roll share one IO — pick a line to filter KPIs, pacing, and daily delivery.
              </p>
              <div
                className="mt-3 grid gap-2 sm:grid-cols-3"
                role="tablist"
                aria-label="Creative line"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeLineId === 'all'}
                  className={`rounded-lg px-4 py-3 text-left text-sm font-semibold transition-colors ${
                    activeLineId === 'all'
                      ? 'bg-navy text-white shadow-md'
                      : 'bg-white text-navy ring-1 ring-slate-300 hover:bg-slate-100'
                  }`}
                  onClick={() => selectCreativeLine('all')}
                >
                  Combined IO
                  <span className={`mt-1 block text-[11px] font-normal ${activeLineId === 'all' ? 'text-white/80' : 'text-slate-500'}`}>
                    Full flight totals
                  </span>
                </button>
                {creativeLines.map((line) => (
                  <button
                    key={line.id}
                    type="button"
                    role="tab"
                    aria-selected={activeLineId === line.id}
                    className={`rounded-lg px-4 py-3 text-left text-sm font-semibold transition-colors ${
                      activeLineId === line.id
                        ? 'bg-navy text-white shadow-md'
                        : 'bg-white text-navy ring-1 ring-slate-300 hover:bg-slate-100'
                    }`}
                    onClick={() => selectCreativeLine(line.id)}
                  >
                    View {line.label}
                    <span className={`mt-1 block text-[11px] font-normal ${activeLineId === line.id ? 'text-white/80' : 'text-slate-500'}`}>
                      {line.kind === 'preroll' ? 'Includes VCR' : 'Native extension'}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      </div>

      <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">
        {hasCreativeLines ? (
          <section
            id="reporting-line-items"
            className="mb-8 scroll-mt-8 rounded-xl border-2 border-navy/25 bg-white p-5 shadow-sm"
          >
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-navy">
                  Line items
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Tap a card to open that run. Export CSV downloads a GAM historical file for that run. Active:{' '}
                  <span className="font-semibold text-navy">
                    {activeLine?.label ?? 'Combined IO'}
                  </span>
                </p>
              </div>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-3">
              <div role="button" tabIndex={0}
                onClick={() => selectCreativeLine('all')}
                className={`rounded-xl border p-4 text-left transition-shadow hover:shadow-md ${
                  activeLineId === 'all'
                    ? 'border-navy bg-navy text-white'
                    : 'border-slate-200 bg-slate-50 text-slate-900'
                }`}
              >
                <p className="text-base font-semibold">Combined IO</p>
                <p className={`mt-1 text-xs ${activeLineId === 'all' ? 'text-white/75' : 'text-slate-500'}`}>
                  {formatNumber(resolveDelivered(campaign.delivery))} imps ·{' '}
                  {formatPercent(campaign.performance.ctrPct, 2)} CTR
                </p>
                <p className={`mt-3 text-sm font-bold underline ${activeLineId === 'all' ? 'text-white' : 'text-navy'}`}>
                  {activeLineId === 'all' ? 'Viewing now' : 'View combined →'}
                </p>
                <button type="button" onClick={(event) => { event.stopPropagation(); exportReportFor('all'); }} className={"mt-3 inline-block rounded-md border px-2 py-1 text-[10px] font-semibold uppercase tracking-wide " + (activeLineId === 'all' ? "border-white/40 text-white hover:bg-white/10" : "border-slate-300 bg-white text-navy hover:bg-slate-50")}>Export CSV</button>
              </div>
              {creativeLineRows.map((row) => (
                <div
                  key={row.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => selectCreativeLine(row.id)}
                  className={`rounded-xl border p-4 text-left transition-shadow hover:shadow-md ${
                    activeLineId === row.id
                      ? 'border-navy bg-navy text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-900'
                  }`}
                >
                  <p className="text-base font-semibold">{row.label}</p>
                  <p className={`mt-1 text-xs ${activeLineId === row.id ? 'text-white/75' : 'text-slate-500'}`}>
                    {formatNumber(row.delivered)} imps · {formatPercent(row.ctr, 2)} CTR
                    {typeof row.vcrPct === 'number' ? ` · ${formatPercent(row.vcrPct, 1)} VCR` : ''}
                    {typeof row.pmpSharePct === 'number' ? ` · ${formatPercent(row.pmpSharePct, 0)} PMP` : ''}
                  </p>
                  <p className={`mt-3 text-sm font-bold underline ${activeLineId === row.id ? 'text-white' : 'text-navy'}`}>
                    {activeLineId === row.id ? 'Viewing now' : `View ${row.label} →`}
                  </p>
                <button type="button" onClick={(event) => { event.stopPropagation(); exportReportFor(row.id); }} className={"mt-3 inline-block rounded-md border px-2 py-1 text-[10px] font-semibold uppercase tracking-wide " + (activeLineId === row.id ? "border-white/40 text-white hover:bg-white/10" : "border-slate-300 bg-white text-navy hover:bg-slate-50")}>Export CSV</button>
                </div>
              ))}
            </div>
          </section>
        ) : null}

        {campaign.landingPage ? (
          <section
            id="reporting-landing-page"
            className="mb-8 scroll-mt-8 rounded-xl border-2 border-navy/25 bg-white p-5 shadow-sm"
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-navy">
                  Landing page performance
                </h2>
                <p className="mt-1 text-sm font-semibold text-slate-900">
                  {campaign.landingPage.headline}
                </p>
                <p className="mt-1 text-sm text-slate-600">{campaign.landingPage.summary}</p>
                <a
                  href={campaign.landingPage.url}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-2 inline-block text-xs font-medium text-navy underline"
                >
                  {campaign.landingPage.url}
                </a>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-slate-200 bg-slate-200 sm:grid-cols-3 lg:grid-cols-6">
              <SnapshotCell
                label="Page views"
                value={formatNumber(campaign.landingPage.pageViews)}
                accent
              />
              <SnapshotCell
                label="Unique visitors"
                value={formatNumber(campaign.landingPage.uniqueVisitors)}
              />
              <SnapshotCell
                label="Avg. time on page"
                value={formatDurationSec(campaign.landingPage.avgTimeOnPageSec)}
                accent
              />
              <SnapshotCell
                label="Bounce rate"
                value={formatPercent(campaign.landingPage.bounceRatePct, 1)}
              />
              <SnapshotCell
                label="Pages / session"
                value={campaign.landingPage.pagesPerSession.toFixed(1)}
              />
              <SnapshotCell
                label="Scroll depth 50%+"
                value={formatPercent(campaign.landingPage.scrollDepth50Pct, 1)}
              />
            </div>
            <h3 className="mt-5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
              Section performance (best → rest)
            </h3>
            <div className="mt-2 overflow-x-auto">
              <table className="w-full min-w-[520px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-[10px] font-bold uppercase tracking-wide text-slate-500">
                    <th className="py-2 pr-4">Section</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Engagement share</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Avg. time</th>
                    <th className="py-2">Note</th>
                  </tr>
                </thead>
                <tbody>
                  {campaign.landingPage.topSections.map((row, i) => (
                    <tr
                      key={row.section}
                      className={`border-b border-slate-100 text-slate-800 ${i === 0 ? 'bg-emerald-50/60' : ''}`}
                    >
                      <td className="py-2.5 pr-4 font-medium">
                        {i === 0 ? (
                          <span className="mr-2 rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-emerald-800">
                            Best
                          </span>
                        ) : null}
                        {row.section}
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums">
                        {formatPercent(row.engagementSharePct, 0)}
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums">
                        {formatDurationSec(row.avgTimeOnSectionSec)}
                      </td>
                      <td className="py-2.5 text-xs text-slate-600">{row.note ?? '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ) : null}

        <h2
          id="reporting-campaign-overview"
          className="scroll-mt-8 text-xs font-bold uppercase tracking-[0.12em] text-slate-500"
        >
          Campaign overview
          {activeLine ? (
            <span className="ml-2 font-semibold normal-case tracking-normal text-navy">
              · {activeLine.label}
            </span>
          ) : null}
        </h2>

        {/* Four overview cards — Trade Desk–style */}
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          <OverviewCard
            eyebrow="Objectives"
            headline={`${delivery.pctDelivered.toFixed(1)}% of booked impressions delivered.`}
            sub={
              overviewObjectiveSub ??
              'Programmatic display delivery against the booked flight and pacing plan.'
            }
            footer="View flight detail"
            footerAnchorId="reporting-flight-detail"
          >
            <div className="flex flex-col items-center gap-2 pt-1">
              {funnelTiers.map((t, i) => (
                <div key={t.label} className="flex w-full flex-col items-center">
                  <div
                    className="flex h-10 items-center justify-center rounded-sm text-center text-[11px] font-semibold text-white shadow-inner transition-all"
                    style={{
                      width: `${t.widthPct}%`,
                      background: i === 0 ? TTD.navy : i === 1 ? TTD.teal : TTD.orangeLight,
                    }}
                  >
                    {formatNumber(t.value)}
                  </div>
                  <span className="mt-1 text-[10px] uppercase tracking-wide text-slate-500">{t.label}</span>
                </div>
              ))}
            </div>
          </OverviewCard>

          <OverviewCard
            eyebrow="Spend & pacing"
            headline={`${formatPercent(delivery.pctDelivered, 0)} of booked volume delivered.`}
            sub={`Booked media ~ $${formatNumber(Math.round(bookedSpend))} · Actual spend ~ $${formatNumber(Math.round(mediaCost))}`}
            footer="View pacing curve"
            footerAnchorId="reporting-pacing-curve"
          >
            <div className="h-[150px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={spendAreaData} margin={{ top: 6, right: 6, left: 2, bottom: 2 }}>
                  <defs>
                    <linearGradient id="spendFillMini" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={TTD.teal} stopOpacity={0.4} />
                      <stop offset="100%" stopColor={TTD.teal} stopOpacity={0.06} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid {...CHART.gridH} vertical={false} />
                  <Area
                    type="monotone"
                    dataKey="spendK"
                    stroke={TTD.teal}
                    fill="url(#spendFillMini)"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="forecastK"
                    stroke={TTD.forecast}
                    strokeDasharray="5 5"
                    strokeWidth={1.5}
                    dot={false}
                  />
                  <XAxis dataKey="shortDate" tick={CHART.tickSm} stroke={TTD.slate} hide />
                  <YAxis tick={CHART.tickSm} stroke={TTD.slate} width={32} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
            <p className="mt-1 text-center text-[10px] text-slate-500">
              Teal = cumulative delivered (000s) · Red dashed = planned cumulative
            </p>
          </OverviewCard>

          <OverviewCard
            eyebrow="Delivery by region"
            headline={`${channelBars[0]?.label ?? 'Geo'} leads impression mix.`}
            sub={campaign.geo.headline}
            footer="View geo breakdown"
            footerAnchorId="reporting-geo-breakdown"
          >
            <div className="h-[150px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={channelBars}
                  layout="vertical"
                  margin={{ top: 2, right: 8, left: 0, bottom: 2 }}
                >
                  <CartesianGrid {...CHART.gridV} horizontal={false} />
                  <XAxis type="number" hide />
                  <YAxis
                    type="category"
                    dataKey="label"
                    width={78}
                    tick={CHART.tickSm}
                    stroke={TTD.slate}
                  />
                  <Bar dataKey="imps" fill={TTD.teal} radius={[0, 4, 4, 0]} barSize={10} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </OverviewCard>

          <OverviewCard
            eyebrow="Audience data"
            headline="Layered cohorts across modeled, purchase, and contextual signals."
            sub={
              isPlanningViewCampaign(campaign.id)
                ? 'Illustrative mix for the overview card; open Audience strategy for this campaign’s cohort list.'
                : 'Illustrative split — modeled, purchase, and contextual paths.'
            }
            footer="View audience deals"
            footerAnchorId="reporting-audience-strategy"
          >
            <div className="h-[150px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={dataActivationPie}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={38}
                    outerRadius={62}
                    paddingAngle={2}
                  >
                    {[TTD.teal, TTD.navy, TTD.orangeLight].map((c, i) => (
                      <Cell key={i} fill={c} stroke="#fff" strokeWidth={2} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={CHART.tooltip.contentStyle} formatter={(v: number) => `${v}%`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </OverviewCard>
        </div>

        {/* Quadrant performance — creative “lines” as bubbles */}
        <section className="mt-10 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
                Creative & format performance
              </h3>
              <p className="mt-2 max-w-2xl text-sm text-slate-600">
                Creative sizes plotted by pacing health vs delivery-to-goal proxy. Bubble area ∝ impressions.
                Reference lines at 90%.
              </p>
            </div>
            <p className="text-[11px] text-slate-400">Hover markers for detail (DSP-style layout).</p>
          </div>

          <div className="relative mt-4 h-[380px] w-full">
            <div className="pointer-events-none absolute inset-0 grid grid-cols-2 grid-rows-2 text-[10px] font-semibold uppercase tracking-wide">
              <div className="flex items-start justify-start p-2 text-amber-900/70">Goal at risk · Pacing ok</div>
              <div className="flex items-start justify-end p-2 text-emerald-900/75">Goal on track · Pacing ok</div>
              <div className="flex items-end justify-start p-2 text-rose-900/75">Goal at risk · Pacing risk</div>
              <div className="flex items-end justify-end p-2 text-blue-900/70">Goal on track · Pacing risk</div>
            </div>
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 28, right: 28, bottom: 28, left: 28 }}>
                <CartesianGrid stroke={TTD.grid} strokeDasharray="4 4" />
                <ReferenceArea x1={0} x2={90} y1={90} y2={100} fill={TTD.quadrant.goalRiskPaceOk} />
                <ReferenceArea x1={90} x2={100} y1={90} y2={100} fill={TTD.quadrant.goalOkPaceOk} />
                <ReferenceArea x1={0} x2={90} y1={0} y2={90} fill={TTD.quadrant.goalRiskPaceRisk} />
                <ReferenceArea x1={90} x2={100} y1={0} y2={90} fill={TTD.quadrant.goalOkPaceRisk} />
                <XAxis
                  type="number"
                  dataKey="goalOnTrack"
                  name="Goal proxy"
                  domain={[40, 100]}
                  tick={CHART.tick}
                  stroke={TTD.slate}
                  label={{ value: 'Delivery / goal health →', position: 'bottom', offset: 0, fontSize: 11 }}
                />
                <YAxis
                  type="number"
                  dataKey="pacing"
                  name="Pacing"
                  domain={[40, 100]}
                  tick={CHART.tick}
                  stroke={TTD.slate}
                  label={{ value: 'Pacing health', angle: -90, position: 'insideLeft', fontSize: 11 }}
                />
                <ZAxis type="number" dataKey="spend" range={[60, 320]} />
                <ReferenceLine
                  x={90}
                  stroke={TTD.refGoal}
                  strokeWidth={1.5}
                  strokeDasharray="5 5"
                  label={{ value: '90% goal', position: 'top', fontSize: 10, fill: TTD.refGoal }}
                />
                <ReferenceLine
                  y={90}
                  stroke={TTD.refPace}
                  strokeWidth={1.5}
                  strokeDasharray="5 5"
                  label={{ value: '90% pace', position: 'right', fontSize: 10, fill: TTD.refPace }}
                />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={CHART.tooltip.contentStyle}
                  formatter={(value: number, name: string, props: { payload?: { name?: string } }) => {
                    if (name === 'spend') return [formatNumber(Math.round(value)), 'Impressions']
                    return [value, name]
                  }}
                  labelFormatter={() => ''}
                  labelStyle={{ display: 'none' }}
                />
                <Scatter name="Creatives" data={bubbleData} fill={TTD.teal}>
                  {bubbleData.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} stroke="#fff" strokeWidth={1} />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Secondary metrics */}
        <section
          className={`mt-6 grid gap-4 ${
            typeof performance.pmpSharePct === 'number' || typeof performance.vcrPct === 'number'
              ? 'lg:grid-cols-2 xl:grid-cols-4'
              : 'lg:grid-cols-3'
          }`}
        >
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Trailing 7-day pace</p>
            <p className="mt-2 text-2xl font-semibold tabular-nums text-slate-900">
              {formatNumber(Math.round(avgDailyLast7))}
              <span className="ml-2 text-sm font-normal text-slate-500">imps / day</span>
            </p>
            <p className="mt-2 text-xs text-slate-600">
              vs prior 7d{' '}
              <span className={pacingWoW >= 0 ? 'font-semibold text-emerald-600' : 'font-semibold text-rose-600'}>
                {pacingWoW >= 0 ? '+' : ''}
                {pacingWoW.toFixed(1)}%
              </span>
            </p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Linear flight pacing</p>
            <p className="mt-2 text-sm leading-snug text-slate-700">
              {tradeDesk.meta.flightPlannedDays}-day linear plan ·{' '}
              <span className={varianceAhead ? 'font-semibold text-emerald-700' : 'font-semibold text-amber-700'}>
                {varianceAhead ? 'Ahead of curve' : 'Monitor'}
              </span>
            </p>
          </div>
          {typeof performance.pmpSharePct === 'number' ? (
            <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
              <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">PMP / endemic share</p>
              <p className="mt-2 text-2xl font-semibold tabular-nums text-slate-900">
                {formatPercent(performance.pmpSharePct, 1)}
              </p>
              <p className="mt-2 text-xs text-slate-600">
                Share of delivered imps on private marketplace / endemic deals — supply mix only; does not change booked or delivered totals.
              </p>
            </div>
          ) : null}
          {typeof performance.vcrPct === 'number' && activeLine?.kind !== 'native' ? (
            <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
              <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">VCR (video complete)</p>
              <p className="mt-2 text-2xl font-semibold tabular-nums text-slate-900">
                {formatPercent(performance.vcrPct, 1)}
              </p>
              <p className="mt-2 text-xs text-slate-600">
                Completes ÷ starts on pre-roll. Separate from click CTR; does not change impression or click totals.
              </p>
            </div>
          ) : null}
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Measurement</p>
            <p className="mt-2 text-sm leading-snug text-slate-600">{performance.measurementNote}</p>
          </div>
        </section>

        {showBillingTable ? (
          <section
            id="reporting-monthly-delivery"
            className="mt-6 scroll-mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <h3 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
              Billing & delivery by period
            </h3>
            {campaign.monthlyDeliveryNote ? (
              <p className="mt-2 text-[11px] leading-snug text-slate-500">{campaign.monthlyDeliveryNote}</p>
            ) : null}
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-[10px] font-bold uppercase tracking-wide text-slate-500">
                    <th className="py-2 pr-4">Period</th>
                    <th className="py-2 pr-4">Dates</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Prod $</th>
                    <th className="py-2 pr-4">Creative</th>
                    <th className="py-2 pr-4">Placements</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Impressions</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Clicks</th>
                    <th className="py-2 text-right tabular-nums">CTR</th>
                  </tr>
                </thead>
                <tbody>
                  {billingPeriodRows.map((row) => (
                    <tr key={row.period} className="border-b border-slate-100 text-slate-800">
                      <td className="py-2.5 pr-4 font-medium">{row.period}</td>
                      <td className="py-2.5 pr-4 whitespace-nowrap text-slate-600">{row.dateLabel}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums">
                        ${row.spendUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 pr-4 font-medium">{row.creativeLabel}</td>
                      <td className="py-2.5 pr-4 max-w-[220px] text-xs leading-snug text-slate-600">
                        {row.placements}
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums">{formatNumber(row.impressions)}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums">{formatNumber(row.clicks)}</td>
                      <td className="py-2.5 text-right tabular-nums">{formatPercent(row.ctrPct, 2)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t border-slate-200 bg-slate-50/80 text-slate-900">
                    <td className="py-2.5 pr-4 font-semibold" colSpan={2}>
                      Flight total
                    </td>
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                      $
                      {billingPeriodRows
                        .reduce((sum, row) => sum + row.spendUsd, 0)
                        .toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 pr-4" colSpan={2} />
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                      {formatNumber(billingPeriodRows.reduce((sum, row) => sum + row.impressions, 0))}
                    </td>
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                      {formatNumber(billingPeriodRows.reduce((sum, row) => sum + row.clicks, 0))}
                    </td>
                    <td className="py-2.5 text-right tabular-nums font-semibold">
                      {formatPercent(
                        (billingPeriodRows.reduce((sum, row) => sum + row.clicks, 0) /
                          Math.max(1, billingPeriodRows.reduce((sum, row) => sum + row.impressions, 0))) *
                          100,
                        2,
                      )}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </section>
        ) : showMonthlyTable ? (
          <section
            id="reporting-monthly-delivery"
            className="mt-6 scroll-mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <h3 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
              Monthly delivery
            </h3>
            {monthlyDeliveryNote ? (
              <p className="mt-2 text-[11px] leading-snug text-slate-500">{monthlyDeliveryNote}</p>
            ) : null}
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[420px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-[10px] font-bold uppercase tracking-wide text-slate-500">
                    <th className="py-2 pr-4">Period</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Impressions</th>
                    <th className="py-2 pr-4 text-right tabular-nums">Clicks</th>
                    <th className="py-2 text-right tabular-nums">CTR</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyRows.map((row) => (
                    <tr key={row.start} className="border-b border-slate-100 text-slate-800">
                      <td className="py-2 pr-4 font-medium">{row.label}</td>
                      <td className="py-2 pr-4 text-right tabular-nums">{formatNumber(row.impressions)}</td>
                      <td className="py-2 pr-4 text-right tabular-nums">{formatNumber(row.clicks)}</td>
                      <td className="py-2 text-right tabular-nums">{formatPercent(row.ctrPct, 2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ) : null}

        {campaign.creativeTraffickingLog?.length ? (
          <section
            id="reporting-trafficking-log"
            className="mt-6 scroll-mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <h3 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
              Creative trafficking log
            </h3>
            <p className="mt-2 text-[11px] leading-snug text-slate-500">
              Where tags were launched, refreshed, or swapped during the flight — partner reconciliation grain.
            </p>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[680px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-[10px] font-bold uppercase tracking-wide text-slate-500">
                    <th className="py-2 pr-4">Date</th>
                    <th className="py-2 pr-4">Event</th>
                    <th className="py-2 pr-4">Creative</th>
                    <th className="py-2 pr-4">Placements updated</th>
                    <th className="py-2">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {campaign.creativeTraffickingLog.map((entry) => (
                    <tr key={`${entry.date}-${entry.action}-${entry.creativeName}`} className="border-b border-slate-100 text-slate-800">
                      <td className="py-2.5 pr-4 whitespace-nowrap tabular-nums text-slate-600">{entry.date}</td>
                      <td className="py-2.5 pr-4">
                        <span
                          className={`inline-flex rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                            entry.action === 'launch'
                              ? 'bg-emerald-50 text-emerald-800'
                              : entry.action === 'swap'
                                ? 'bg-violet-50 text-violet-800'
                                : entry.action === 'close'
                                  ? 'bg-slate-100 text-slate-600'
                                  : 'bg-sky-50 text-sky-800'
                          }`}
                        >
                          {traffickingActionLabel(entry.action)}
                        </span>
                      </td>
                      <td className="py-2.5 pr-4">
                        <p className="font-medium">{entry.creativeName}</p>
                        {entry.headline ? (
                          <p className="mt-0.5 text-xs leading-snug text-slate-600">{entry.headline}</p>
                        ) : null}
                        {entry.destinationUrl ? (
                          <a
                            href={entry.destinationUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-1 block max-w-[240px] truncate text-xs text-navy underline"
                          >
                            {entry.destinationUrl.replace(/^https?:\/\//, '')}
                          </a>
                        ) : null}
                      </td>
                      <td className="py-2.5 pr-4 max-w-[240px] text-xs leading-snug text-slate-600">
                        {entry.placementsUpdated}
                      </td>
                      <td className="py-2.5 text-xs leading-snug text-slate-600">{entry.notes ?? '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ) : null}

        {/* Detailed charts — full width */}
        <section
          id="reporting-pacing-curve"
          className="mt-10 scroll-mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
        >
          <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
            Cumulative impression pacing
          </h3>
          <div className="mt-4 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={cumulativeChartData} margin={CHART.marginLg}>
                <defs>
                  <linearGradient id="planBandMain" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={TTD.plan} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={TTD.plan} stopOpacity={0.06} />
                  </linearGradient>
                </defs>
                <CartesianGrid {...CHART.gridH} vertical={false} />
                <XAxis dataKey="shortDate" tick={CHART.tick} stroke={TTD.slate} />
                <YAxis
                  tick={CHART.tick}
                  stroke={TTD.slate}
                  tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : `${v}`)}
                />
                <Tooltip contentStyle={CHART.tooltip.contentStyle} />
                <Legend {...CHART.legend} />
                <Area
                  type="monotone"
                  dataKey="cumulativePlanned"
                  name="Planned cumulative"
                  stroke={TTD.plan}
                  fill="url(#planBandMain)"
                  fillOpacity={1}
                />
                <Line
                  type="monotone"
                  dataKey="cumulativeActual"
                  name="Actual cumulative"
                  stroke={TTD.teal}
                  strokeWidth={2.5}
                  dot={false}
                />
                <ReferenceLine
                  y={delivery.impressionsPurchased}
                  stroke={TTD.refCap}
                  strokeDasharray="5 5"
                  strokeWidth={1.5}
                  label={{ value: 'Booked cap', fontSize: 10, fill: TTD.refCap }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
            Daily delivery vs plan
          </h3>
          <div className="mt-4 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={cumulativeChartData.map((d) => ({ ...d, variance: d.actualImp - d.plannedImp }))}
                margin={CHART.marginLg}
              >
                <CartesianGrid {...CHART.gridH} vertical={false} />
                <XAxis dataKey="shortDate" tick={CHART.tick} stroke={TTD.slate} />
                <YAxis yAxisId="left" tick={CHART.tick} stroke={TTD.slate} />
                <Tooltip contentStyle={CHART.tooltip.contentStyle} />
                <Legend {...CHART.legend} />
                <Bar
                  yAxisId="left"
                  dataKey="actualImp"
                  name="Actual imps"
                  fill={TTD.teal}
                  radius={[4, 4, 0, 0]}
                  maxBarSize={56}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="plannedImp"
                  name="Planned daily slice"
                  stroke={TTD.navyMuted}
                  strokeDasharray="6 4"
                  strokeWidth={2}
                  dot={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </section>

        <div className="mt-6 grid gap-6 xl:grid-cols-2">
          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">CTR trend</h3>
            <div className="mt-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={cumulativeChartData} margin={CHART.marginMd}>
                  <CartesianGrid {...CHART.gridH} vertical={false} />
                  <XAxis dataKey="shortDate" tick={CHART.tick} stroke={TTD.slate} />
                  <YAxis tick={CHART.tick} stroke={TTD.slate} tickFormatter={(v) => `${v.toFixed(2)}%`} />
                  <Tooltip
                    contentStyle={CHART.tooltip.contentStyle}
                    formatter={(v: number) => [`${v.toFixed(3)}%`, 'CTR']}
                  />
                  <Legend {...CHART.legend} />
                  <ReferenceLine
                    y={performance.ctrPct}
                    stroke={TTD.refGoal}
                    strokeDasharray="5 5"
                    strokeWidth={1.5}
                    label={{ value: 'Blended avg', fontSize: 10, fill: TTD.refGoal }}
                  />
                  <Line
                    type="monotone"
                    dataKey="ctr"
                    name="CTR"
                    stroke={TTD.navy}
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Pace index vs plan</h3>
            <div className="mt-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={cumulativeChartData} margin={CHART.marginMd}>
                  <CartesianGrid {...CHART.gridH} vertical={false} />
                  <XAxis dataKey="shortDate" tick={CHART.tick} stroke={TTD.slate} />
                  <YAxis tick={CHART.tick} stroke={TTD.slate} tickFormatter={(v) => `${v.toFixed(0)}%`} />
                  <Tooltip contentStyle={CHART.tooltip.contentStyle} />
                  <Legend {...CHART.legend} />
                  <ReferenceLine y={0} stroke={TTD.slate} strokeDasharray="4 4" />
                  <Line
                    type="monotone"
                    dataKey="pacePct"
                    name="Δ vs plan"
                    stroke={TTD.refPace}
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <section
            id="reporting-geo-breakdown"
            className="scroll-mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <h3 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
              Geo mix
            </h3>
            <p className="mt-2 text-[11px] text-slate-500">{campaign.geo.headline}</p>
            <div className="mt-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={tradeDesk.geoDelivery.map((g) => ({
                    ...g,
                    label: g.region.length > 14 ? `${g.region.slice(0, 12)}…` : g.region,
                  }))}
                  layout="vertical"
                  margin={{ top: 10, right: 18, left: 8, bottom: 10 }}
                >
                  <CartesianGrid {...CHART.gridV} horizontal={false} />
                  <XAxis type="number" tick={CHART.tick} stroke={TTD.slate} />
                  <YAxis type="category" dataKey="label" width={96} tick={CHART.tick} stroke={TTD.slate} />
                  <Tooltip contentStyle={CHART.tooltip.contentStyle} />
                  <Bar dataKey="impressions" fill={TTD.teal} radius={[0, 4, 4, 0]} maxBarSize={28} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
              Format mix
            </h3>
            <p className="mt-2 text-[11px] text-slate-500">{creative.environments}</p>
            <div className="mt-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={tradeDesk.formatDelivery} margin={{ top: 12, right: 14, left: 10, bottom: 52 }}>
                  <CartesianGrid {...CHART.gridH} vertical={false} />
                  <XAxis
                    dataKey="format"
                    tick={CHART.tickSm}
                    stroke={TTD.slate}
                    angle={-35}
                    textAnchor="end"
                    height={56}
                  />
                  <YAxis tick={CHART.tick} stroke={TTD.slate} />
                  <Tooltip contentStyle={CHART.tooltip.contentStyle} />
                  <Bar dataKey="impressions" fill={TTD.teal} radius={[4, 4, 0, 0]} maxBarSize={48} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
              Device share
            </h3>
            <div className="mt-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={devicePieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={48}
                    outerRadius={78}
                    paddingAngle={2}
                  >
                    {[TTD.teal, TTD.navy, TTD.orangeLight].map((c, i) => (
                      <Cell key={i} fill={c} stroke="#fff" strokeWidth={2} />
                    ))}
                  </Pie>
                  <Legend {...CHART.legend} />
                  <Tooltip
                    contentStyle={CHART.tooltip.contentStyle}
                    formatter={(v: number) => `${v.toFixed(1)}%`}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>

        <section
          id={hasCreativeLines ? 'reporting-io-meta' : 'reporting-line-items'}
          className="mt-8 scroll-mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
        >
          <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
            {hasCreativeLines ? 'IO / insertion meta' : 'Line item detail'}
            {activeLine ? (
              <span className="ml-2 font-semibold normal-case tracking-normal text-navy">
                · {activeLine.label}
              </span>
            ) : null}
          </h3>
          <p className="mt-2 text-sm text-slate-600">
            {hasCreativeLines
              ? 'Active line DSP metadata — use the Line items table above to switch Native vs Pre-roll.'
              : 'Insertion IDs and supply path — mirror your DSP line item when connecting warehouse feeds.'}
          </p>
          <dl className="mt-4 grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">IO number</dt>
              <dd className="mt-1 font-medium tabular-nums text-slate-900">{tradeDesk.meta.ioNumber}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Line item</dt>
              <dd className="mt-1 font-medium text-slate-900">{tradeDesk.meta.lineItem}</dd>
            </div>
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">DSP</dt>
              <dd className="mt-1 text-slate-800">{tradeDesk.meta.dsp}</dd>
            </div>
            <div className="lg:col-span-2">
              <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Supply path</dt>
              <dd className="mt-1 text-slate-800">{tradeDesk.meta.supplyPath}</dd>
            </div>
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Currency</dt>
              <dd className="mt-1 tabular-nums text-slate-800">{tradeDesk.meta.currency}</dd>
            </div>
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Last data date</dt>
              <dd className="mt-1 tabular-nums text-slate-800">{tradeDesk.meta.lastDataDate}</dd>
            </div>
          </dl>
        </section>

        {/* Daily table */}
        <section
          id="reporting-flight-detail"
          className="mt-8 scroll-mt-8 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"
        >
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 bg-slate-50 px-5 py-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-600">Daily grain · export</h3>
              <p className="mt-1 text-[11px] text-slate-500">
                One row per day for the run you are viewing. Download CSV saves a GAM historical file for that run.
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportReport}
              className="shrink-0 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-navy shadow-sm transition-colors hover:bg-slate-50"
            >
              Download CSV
            </button>
          </div>
          <div className="max-h-[420px] overflow-auto">
            <table className="w-full min-w-[900px] border-collapse text-left text-xs">
              <thead className="sticky top-0 z-10 bg-slate-100 text-[10px] font-semibold uppercase tracking-wide text-slate-600">
                <tr>
                  <th className="border-b border-slate-200 px-3 py-2">Date</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Planned</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Actual</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Δ</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Clicks</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">CTR</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Cum act.</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Cum plan</th>
                  <th className="border-b border-slate-200 px-2 py-2 text-right">Pace %</th>
                </tr>
              </thead>
              <tbody className="text-slate-800">
                {tradeDesk.daily.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-3 py-8 text-center text-sm text-slate-500">
                      No daily rows in this export.
                    </td>
                  </tr>
                ) : (
                  tradeDesk.daily.map((row) => {
                  const delta = row.actualImp - row.plannedImp
                  return (
                    <tr key={row.date} className="border-b border-slate-100 hover:bg-slate-50/90">
                      <td className="whitespace-nowrap px-3 py-1.5 text-slate-600">{row.date}</td>
                      <td className="px-2 py-1.5 text-right tabular-nums">{formatNumber(row.plannedImp)}</td>
                      <td className="px-2 py-1.5 text-right tabular-nums font-medium">{formatNumber(row.actualImp)}</td>
                      <td
                        className={`px-2 py-1.5 text-right tabular-nums ${
                          delta >= 0 ? 'text-emerald-800' : 'text-rose-800'
                        }`}
                      >
                        {delta >= 0 ? '+' : ''}
                        {formatNumber(delta)}
                      </td>
                      <td className="px-2 py-1.5 text-right tabular-nums">{formatNumber(row.clicks)}</td>
                      <td className="px-2 py-1.5 text-right tabular-nums">{row.ctr.toFixed(3)}%</td>
                      <td className="px-2 py-1.5 text-right tabular-nums text-slate-600">
                        {formatNumber(row.cumulativeActual)}
                      </td>
                      <td className="px-2 py-1.5 text-right tabular-nums text-slate-600">
                        {formatNumber(row.cumulativePlanned)}
                      </td>
                      <td className="px-2 py-1.5 text-right tabular-nums">
                        {(row.paceIndex * 100).toFixed(1)}%
                      </td>
                    </tr>
                  )
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section
          id="reporting-creative"
          className="mt-8 scroll-mt-8 rounded-xl border border-slate-200 bg-white p-6 shadow-sm"
        >
          <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
            Click-through & assets
            {activeLine ? (
              <span className="ml-2 font-semibold normal-case tracking-normal text-navy">
                · {activeLine.label}
              </span>
            ) : null}
          </h3>
          <p className="mt-2 text-sm text-slate-600">{tracking.description}</p>
          <p className="mt-3 break-all rounded-lg bg-slate-50 p-3 text-xs text-navy underline">
            <a href={tracking.clickthroughUrl} target="_blank" rel="noreferrer">
              {tracking.clickthroughUrl}
            </a>
          </p>
          {activeLine?.tracking.pixelUrl ? (
            <div className="mt-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">
                Tourism Economic / 1×1 pixel
              </p>
              <p className="mt-2 break-all rounded-lg bg-slate-50 p-3 text-xs text-slate-700">
                {activeLine.tracking.pixelUrl}
              </p>
            </div>
          ) : null}
          <p className="mt-4 text-sm font-medium text-navy">
            <a href={creative.assetsFolderUrl} target="_blank" rel="noreferrer">
              Creative assets folder →
            </a>
          </p>
        </section>

        <section id="reporting-audience-strategy" className="mt-8 scroll-mt-8">
          <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Audience strategy</h3>
          <div className="mt-4 space-y-4">
            {campaign.audiences.map((bucket) => (
              <article key={bucket.id} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                <h4 className="text-base font-semibold text-slate-900">{bucket.label}</h4>
                <p className="mt-1 text-sm text-slate-600">{bucket.description}</p>
                <ul className="mt-4 divide-y divide-slate-100 border-t border-slate-100">
                  {bucket.cohorts.map((c) => (
                    <li key={c.title} className="flex gap-3 py-3 first:pt-4">
                      <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-navy" />
                      <div>
                        <p className="text-sm font-medium text-slate-900">{c.title}</p>
                        <p className="mt-1 text-sm leading-relaxed text-slate-600">{c.detail}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section
          id="reporting-schedule-report"
          className="mt-8 scroll-mt-8 rounded-xl border border-dashed border-slate-300 bg-slate-50 p-6 shadow-sm"
        >
          <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Schedule report delivery</h3>
          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            Ask for recurring CSV exports or summary emails. We confirm cadence, filters, and recipients with your team.
          </p>
          <a
            href={`mailto:hello@vrvo.co?subject=${encodeURIComponent(`Report schedule: ${campaign.name}`)}&body=${encodeURIComponent(
              `Campaign: ${campaign.name} (${campaign.id})\n\nPreferred cadence (e.g. weekly / monthly):\nRecipients:\nNotes:\n`,
            )}`}
            className="mt-4 inline-flex items-center rounded-md bg-navy px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-navy/90"
          >
            Email hello@vrvo.co to schedule
          </a>
        </section>

        <footer className="mt-12 border-t border-slate-200 pt-6 text-center text-[10px] text-slate-500">
          Campaign ID {campaign.id} · UI aligned to common DSP overview patterns — not affiliated with The Trade Desk.
        </footer>
      </div>
    </div>
  )
}

function SnapshotCell({
  label,
  value,
  accent,
}: {
  label: string
  value: string
  accent?: boolean
}) {
  return (
    <div className={`bg-white px-3 py-3 sm:px-4 ${accent ? 'ring-1 ring-inset ring-teal-600/20' : ''}`}>
      <p className="text-[9px] font-semibold uppercase tracking-wide text-slate-500">{label}</p>
      <p
        className={`mt-1 text-base tabular-nums sm:text-lg ${accent ? 'font-semibold text-navy' : 'font-medium text-slate-900'}`}
      >
        {value}
      </p>
    </div>
  )
}

function OverviewCard({
  eyebrow,
  headline,
  sub,
  footer,
  footerAnchorId,
  children,
}: {
  eyebrow: string
  headline: string
  sub?: string
  footer: string
  /** In-page section `id` for smooth scroll (reporting dashboard). */
  footerAnchorId?: string
  children: ReactNode
}) {
  return (
    <div className="flex min-h-[280px] flex-col rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">{eyebrow}</p>
      <p className="mt-2 text-[15px] font-semibold leading-snug text-slate-900">{headline}</p>
      {sub ? <p className="mt-2 text-[11px] leading-snug text-slate-500">{sub}</p> : null}
      <div className="mt-3 flex flex-1 flex-col">{children}</div>
      {footerAnchorId ? (
        <a
          href={`#${footerAnchorId}`}
          className="mt-3 inline-block text-left text-[11px] font-semibold uppercase tracking-wide text-navy underline decoration-navy/30 underline-offset-2 transition-colors hover:text-navy hover:decoration-navy"
          onClick={(e) => {
            e.preventDefault()
            scrollToReportingSection(footerAnchorId)
          }}
        >
          {footer}
        </a>
      ) : (
        <span className="mt-3 text-left text-[11px] font-semibold uppercase tracking-wide text-navy/50">
          {footer}
        </span>
      )}
    </div>
  )
}
